package day01.class04;

public class Quiz01 {
	public static void main(String[] args) {
		/*
		System.out.println(1);
		System.out.print(2);
		System.out.print(3);
		System.out.println(4);
		System.out.println(5);
		*/
		System.out.println("1\n234\n5");
	}
}
