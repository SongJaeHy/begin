package day01;
public class Test02 {

}
