package day04.loop;

public class Quiz02 {
	public static void main(String[] args) {
		// 10, 20, 30, 40 ,50
		// for ���� �̿��Ѵ�.
		for (int i = 1; i < 6; i++) {
			System.out.println(i * 10);
		}
	}
}
